package co.edu.uniempresarial;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
 
@RestController
public class PrimerProyectoController {
	@GetMapping(value="control1" , produces = MediaType.APPLICATION_JSON_VALUE)
	public String primerControlador() {
		return "Controlador 1"; 
	}
	//Recibiendo valores(variable) en la URL
	@GetMapping(value= "addition/{num1}/{num2}" , produces = MediaType.APPLICATION_JSON_VALUE)
	public double sumar(@PathVariable("num1")double numero1, @PathVariable("num2")double numero2) {
		return numero1 + numero2;
	}
	@RequestMapping(value="sustract", method = RequestMethod.GET)
	public double restar1(@RequestParam("num1")double numero1,
		@RequestParam("num2")double numero2) {
	return numero1 - numero2;
	}
	@RequestMapping(value="multiplicar", method = RequestMethod.GET)
	public double multiplicar(@RequestParam("num1")double numero1,
		@RequestParam("num2")double numero2, @RequestParam("num3")double numero3) {
		return numero1 * numero2 * numero3;
	}
	@RequestMapping(value="dividir", method = RequestMethod.GET)
	public double dividir (@RequestParam("num1")double numero1,
		@RequestParam("num2")double numero2) {
		return numero1 / numero2;
	}
	@RequestMapping(value="exponenciacion", method = RequestMethod.GET)
	public double exponenciacion (@RequestParam("num1")double numero1) {
		return numero1 * numero1;
	}
	@RequestMapping(value = "raiz", method = RequestMethod.GET)
	public double raiz(@RequestParam("num1") double numero1) {
	    return Math.sqrt(numero1);
	}
}	
