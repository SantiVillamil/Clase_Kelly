package co.edu.uniempresarial.entity;

import java.util.ArrayList;

public class Curso {
	private long id;
	private String nombre;
	private String descripcion;
	private double costo;
	private int capacidad;
	ArrayList<Curso> lista;
	
	public Curso(long id, String nombre, String descripcion, double costo, int capacidad) {
		super();
		this.id = id;
		this.nombre = nombre;
		this.descripcion = descripcion;
		this.costo = costo;
		this.capacidad = capacidad;
	}
	

	public Curso() {
		super();
		this.listaCursos();
	}


	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public double getCosto() {
		return costo;
	}

	public void setCosto(double costo) {
		this.costo = costo;
	}

	public int getCapacidad() {
		return capacidad;
	}

	public void setCapacidad(int capacidad) {
		this.capacidad = capacidad;
	}
    
	public ArrayList<Curso> getLista() {
		return this.lista;
	}

	@Override
	public String toString() {
		return "Curso [id=" + id + ", nombre=" + nombre + ", descripcion=" + descripcion + ", costo=" + costo
				+ ", capacidad=" + capacidad + "]";
	}
	
	public ArrayList<Curso> listaCursos(){
		this.lista = new ArrayList<Curso>();
		
		lista.add(new Curso(1,"JAVA","CURSO INICIO JAVA",20,15));
		lista.add(new Curso(2,"JAVA2","CURSO AVANZADO JAVA",40,15));
		lista.add(new Curso(3,"PYTHON","CURSO BASICO PYTHON",25,15));
		lista.add(new Curso(4,"C#","CURSO INICIO C#",18,10));
		lista.add(new Curso(5,"RUBY","CURSO RUBY",25,20));
		lista.add(new Curso(6,"PHP","CURSO PHP",15,15));
		lista.add(new Curso(7,"PYTHON2","CURSO AVANZADO PYTHON",35,15));
		return lista;
	}
	
	public ArrayList<Curso> buscarCurso(String nombreCurso){
		
		ArrayList<Curso> listAux = new ArrayList<>();
		ArrayList<Curso> listReturn = new ArrayList<>();
		
		listAux= this.lista;
		for(Curso c: listAux) {
			if(c.getNombre().contains(nombreCurso)) {
				listReturn.add(c);
			}
		}
		
	return listReturn;
	  }
	
	public ArrayList<Curso> agregarCurso(Curso course){
		ArrayList<Curso> listAux = new ArrayList<>();
		
		listAux = this.listaCursos();
		if(!course.equals(null)) {
			listAux.add(course);
			this.lista = listAux;
		}
		return this.lista;									
	}
	}
	
	


