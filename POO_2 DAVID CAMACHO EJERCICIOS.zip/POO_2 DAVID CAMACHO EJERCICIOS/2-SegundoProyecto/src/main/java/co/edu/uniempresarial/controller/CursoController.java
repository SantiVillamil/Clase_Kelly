package co.edu.uniempresarial.controller;

import java.util.ArrayList;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import co.edu.uniempresarial.entity.Curso;

@RestController
@RequestMapping(value="web")
public class CursoController {
	
	private Curso cursito = new Curso();
	
	@GetMapping(value="cursos", produces = MediaType.APPLICATION_JSON_VALUE)
	public ArrayList<Curso> getAllCourses(){
		return cursito.getLista();
	}
	
	@GetMapping(value="buscar/{name}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ArrayList<Curso> getByCuourseName(@RequestParam("name") String name){
		return cursito.buscarCurso(name.toUpperCase());
		
	}
	
	@PostMapping(value="curso", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public String postCurso (@RequestBody Curso course){
		ArrayList<Curso> cursos = new ArrayList<>();
		int sizeIni= cursito.getLista().size();
		cursos = cursito.agregarCurso(course);
		int sizeEnd= cursito.getLista().size();
		if(sizeEnd > sizeIni) return "se agrego el curso";
		else return "no se agrego el curso";
    }
}	
	
