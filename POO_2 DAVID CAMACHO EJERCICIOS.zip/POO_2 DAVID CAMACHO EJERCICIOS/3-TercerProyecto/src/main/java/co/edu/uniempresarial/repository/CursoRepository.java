package co.edu.uniempresarial.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import co.edu.uniempresarial.entity.Curso;

@Repository
public class CursoRepository {
	List<Curso> lista;
	
	
	
	public CursoRepository() {
		super();
		listaCursos();
	}

	public List<Curso> listaCursos(){
		this.lista = new ArrayList<Curso>();
		if(this.lista.isEmpty()) {
		
		this.lista.add(new Curso(1,"JAVA","CURSO INICIO JAVA",20,15));
		this.lista.add(new Curso(2,"JAVA2","CURSO AVANZADO JAVA",40,15));
		this.lista.add(new Curso(3,"PYTHON","CURSO BASICO PYTHON",25,15));
		this.lista.add(new Curso(4,"C#","CURSO INICIO C#",18,10));
		this.lista.add(new Curso(5,"RUBY","CURSO RUBY",25,20));
		this.lista.add(new Curso(6,"PHP","CURSO PHP",15,15));
		this.lista.add(new Curso(7,"PYTHON2","CURSO AVANZADO PYTHON",35,15));
		}
		return lista;
	}
	
	public List<Curso> buscarCurso(String nombreCurso){
		
		List<Curso> listAux = new ArrayList<>();
		List<Curso> listReturn = new ArrayList<>();
		
		listAux= this.lista;
		for(Curso c: listAux) {
			if(c.getNombre().contains(nombreCurso)) {
				listReturn.add(c);
			}
		}
		
	return listReturn;
	  }
	
	public List<Curso> agregarCurso(Curso course){
	List<Curso> listAux = new ArrayList<>();
		
		listAux = this.listaCursos();
		if(!course.equals(null)) {
			listAux.add(course);
			this.lista = listAux;
		}
		return this.lista;									
	}
	
	public Curso getCursoPorID(Long id) {
		return this.lista.stream().filter(i->i.getId().equals(id)).findFirst().orElseThrow();
	}
	
	public List<Curso> borrarCurso(long id){
		this.lista.removeIf(c->c.getId().equals(id));
		return this.lista;
	}
}
