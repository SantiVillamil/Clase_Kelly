package co.edu.uniempresarial.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import co.edu.uniempresarial.entity.Curso;
import co.edu.uniempresarial.repository.CursoRepository;
import jakarta.annotation.PostConstruct;

@RestController
@RequestMapping(value="web")
public class CursoController {
	
	CursoRepository cursito;
		
	@PostConstruct
	public void init() {
		cursito = new CursoRepository();
	}
	@GetMapping(value="cursos", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Curso> getAllCourses(){
		return cursito.listaCursos();
	}
	
	@GetMapping(value="buscar-nombre", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Curso> getByCuourseName(@RequestParam("name") String name){
		return cursito.buscarCurso(name.toUpperCase());
		}
	@GetMapping(value="buscar-id", produces = MediaType.APPLICATION_JSON_VALUE)
	public Curso getByCuourseId(@RequestParam("id")long id){
		return cursito.getCursoPorID(id);
		}
	    //agregar nuevo curso
	@PostMapping(value="curso", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public List<Curso>  postCurso (@RequestBody Curso course){
		return cursito.agregarCurso(course);
    }
	    //eliminar curso
	@DeleteMapping(value="curso", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Curso> deleteCurso(@RequestParam("id")long id){
		return cursito.borrarCurso(id);
	}
}